import re

def current_year():
	return 2021